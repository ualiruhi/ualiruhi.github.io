# Matomo

```toml
[params.matomo]
    siteID = "ABCDE"
    serverURL = "analytics.example.com"
```
