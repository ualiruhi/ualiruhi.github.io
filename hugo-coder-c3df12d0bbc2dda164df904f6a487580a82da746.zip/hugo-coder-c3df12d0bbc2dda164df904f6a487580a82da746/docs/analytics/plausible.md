# Plausible Analytics

```toml
[params.plausibleAnalytics]
  domain = "example.com"
  serverURL = "plausible.io" # (optionnal) Replace if you use a custom domain
```
