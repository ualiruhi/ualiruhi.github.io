# Fathom Analytics

```toml
[params.fathomAnalytics]
  siteID = "ABCDE"
  serverURL = "cdn.usefathom.com" # (optionnal) Replace if you use a custom domain
```