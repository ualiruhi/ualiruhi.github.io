# Welcome to the hugo-coder docs!

## Basic Usage

* [Quick Start](quick-start.md)
* [Configurations](configurations.md)
* [FAQ](faq.md)

## Extra Guides

* [Multilingual Mode](multilingual-mode.md)
* [Comment System](comment-system.md)
* [Analytics](analytics.md)

## Maintainers & Developers

* [Contributing](contributing.md)


